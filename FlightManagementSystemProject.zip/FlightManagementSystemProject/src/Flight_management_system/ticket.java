package Flight_management_system;

import src.BookTickets;

public class ticket extends BookTickets{
	 
    int tkt()
	{
		
		return tktnum;
		
	}

}
